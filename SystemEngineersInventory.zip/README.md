# System Engineers Inventory - Excel Add-in

This **Excel Add-in** provides a GUI for filtering, sorting, and managing **System Engineer Inventory**.

## 📌 Features
✅ **Filter engineers by System Type (Server, Storage, Networking)**  
✅ **Sort engineers alphabetically**  
✅ **Export data to CSV**  
✅ **Works in Excel (Local & Web)**  

## 🚀 Installation
1. **Enable Developer Mode in Excel**  
   - Go to **File → Options → Customize Ribbon**  
   - Enable **Developer Tab**  

2. **Load the Add-in**  
   - Open **Excel → Developer → Add-ins → Sideload Add-in**  
   - Select `manifest.xml`  

3. **Use the Add-in**  
   - Open **Excel → Insert → Add-ins → System Engineers Inventory**  
   - Use the **buttons** to filter, sort, and export data.  

## 📂 Repository Structure
- `index.html` → User Interface  
- `scripts/functions.js` → Excel automation scripts  
- `manifest.xml` → Office Add-in registration  
- `README.md` → Setup Guide  

## 🛠 Future Enhancements
- 📊 **Graphical Dashboard**  
- 🖥 **Data Sync with Database**  
- 📈 **Advanced Reporting**  

**Developed by:** _Your Name_ 🚀  
